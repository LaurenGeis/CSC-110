package Demo1NumbersTest;
import static java.lang.System.out;
public class InputOutPut1 {

    public static void main(String... args) {
        var startValue =1;
        var endValue = 100;
        var incrementValue  = 5;

        // it is always a good idea to inform what is happening
        out.println("Start of process");
        // reformated the code so that it in in the general standard form
        for( startValue = 0; startValue<= endValue ; startValue = startValue + incrementValue){ // you process code here
              
            PrintData("The current Value", startValue);
        }
    }
    
    public static void PrintData(String message, Integer value){
        var header = "-"; 
        var outout = message + "  = " + value;
        System.out.println( header.repeat(outout.length()) );
        System.out.println(outout);
        System.out.println( header.repeat(outout.length()) );

    }
}    
        


