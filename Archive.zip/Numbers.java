package Demo1NumbersTest;
import static java.lang.System.out;
public class Numbers {

    public static void main(String... args) {
        var number = 0;
        out.println(number);
    }      
}
